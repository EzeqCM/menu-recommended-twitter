import { useState } from "react";

function Button(){

    return(
        <div>
            <button>Seguir</button>
        </div>
    );
}
export default Button;