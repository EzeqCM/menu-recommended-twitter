import './HelloWorld.css'
function HelloWorld(){
    return(
        <h3>Talvez você curta</h3>
    );
}
export default HelloWorld;
